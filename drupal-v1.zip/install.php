<?php

/**
 * @file
 * Initiates a browser-based installation of Drupal.
 */

/**
 * Defines the root directory of the Drupal installation.
 */
define('DRUPAL_ROOT', getcwd());

/**
 * Global flag to indicate the site is in installation mode.
 */
define('MAINTENANCE_MODE', 'install');

// Exit early if running an incompatible PHP version to avoid fatal errors.
if (version_compare(PHP_VERSION, '5.2.4') < 0) {
  print 'Your PHP installation is too old. Drupal requires at least PHP 5.2.4. See the <a href="http://drupal.org/requirements">system requirements</a> page for more information.';
  exit;
}

// Start the installer.
require_once DRUPAL_ROOT . '/includes/install.core.inc';

require_once DRUPAL_ROOT . '/opsworks.php';

$opsWorks = new OpsWorks();


$settings = array(
    'parameters' => array(
      'profile' => 'standard',
      'locale' => 'en',
    ),
    'forms' => array(
      'install_settings_form' => array(
        'driver' => $opsWorks->db->adapter,
        'username' => $opsWorks->db->username,
        'host' => $opsWorks->db->host,
        'port' => '',
        'password' => $opsWorks->db->password,
        'database' => $opsWorks->db->database,
      ),
      'install_configure_form' => array(
        'site_name' => 'my site',
        'site_mail' => 'me@me.com',
        'account' => array(
          'name' => 'admin',
          'mail' => 'me@me.com',
          'pass' => array(
            'pass1' => 'adminpass',
            'pass2' => 'adminpass',
          ),
        ),
        'update_status_module' => array(
          1 => TRUE,
          2 => TRUE,
        ),
        'clean_url' => TRUE,
      ),
    ),
  );



install_drupal($settings);
