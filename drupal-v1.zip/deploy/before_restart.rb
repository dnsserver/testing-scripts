node[:deploy].each do |app_name, deploy_config|
  # determine root folder of new app deployment
  app_root = "#{deploy_config[:current_path]}"

  bash "install_drupal" do
    user "root"
    cwd "#{app_root}"
    code <<-EOH
      echo "In #{app_root}" > dump.txt
      if [ ! -f #{app_root}/sites/default/settings.php ]; then
        cp #{app_root}/sites/default/default.settings.php #{app_root}/sites/default/settings.php
        echo "Copy settings.php: $?" >> dump.txt
        chmod a+w #{app_root}/sites/default/settings.php
        echo "Chmod settings.php: $?" >> dump.txt
      
        if [ ! -d #{app_root}/sites/default/files ]; then
            mkdir #{app_root}/sites/default/files
            echo "Make files dir: $?" >> dump.txt
            chmod a+w #{app_root}/sites/default/files
            echo "Chmod files dir: $?" >> dump.txt
        fi
        /usr/bin/php #{app_root}/install.php
        echo "Run install.php: $?" >> dump.txt
        chmod a-w #{app_root}/sites/default/settings.php
        echo "Chmod settings.php: $?" >> dump.txt
      fi
    EOH
  end
end
