node[:deploy].each do |app_name, deploy_config|
  # determine root folder of new app deployment
  app_root = "#{deploy_config[:current_path]}"

  bash "install_drupal" do
    user "root"
    cwd "#{app_root}"
    code <<-EOH
      echo "In #{app_root}" > dump.txt
      cp #{app_root}/sites/default/default.settings.php #{app_root}/sites/default/settings.php
      echo "Copy settings.php: $?" >> dump.txt
      mkdir #{app_root}/sites/default/files
      echo "Make files dir: $?" >> dump.txt
      chmod a+w #{app_root}/sites/default/files
      echo "Chmod files dir: $?" >> dump.txt
      chmod a+w #{app_root}/sites/default/settings.php
      echo "Chmod settings.php: $?" >> dump.txt
      /usr/bin/php #{app_root}/install.php
      echo "Run install.php: $?" >> dump.txt
      chmod a-w #{app_root}/sites/default/settings.php
      echo "Chmod settings.php: $?" >> dump.txt
    EOH
    not_if do
      File.exists?("#{app_root}/sites/default/settings.php")
    end
  end
end
