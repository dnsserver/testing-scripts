node[:deploy].each do |app_name, deploy_config|
  # determine root folder of new app deployment
  app_root = "#{deploy_config[:current_path]}"
  host = "#{deploy_config[:database][:host]}"
  database = "#{deploy_config[:database][:database]}"
  user = "#{deploy_config[:database][:username]}"
  pass = "#{deploy_config[:database][:password]}"

  bash "install_drupal" do
    user "root"
    cwd "#{app_root}"
    code <<-EOH
      if [ ! -f #{app_root}/sites/default/settings.php ]; then
        mysql -h #{host} -u #{user} -p#{pass} -e "CREATE DATABASE IF NOT EXISTS #{database}"
        cp #{app_root}/sites/default/default.settings.php #{app_root}/sites/default/settings.php
        chmod a+w #{app_root}/sites/default/settings.php
      
        if [ ! -d #{app_root}/sites/default/files ]; then
            mkdir #{app_root}/sites/default/files
            chmod a+w #{app_root}/sites/default/files
        fi
        /usr/bin/php #{app_root}/install.php
        chmod a-w #{app_root}/sites/default/settings.php
      fi
    EOH
  end
end
