node[:deploy].each do |app_name, deploy_config|
  # determine root folder of new app deployment
  #app_root = "#{deploy_config[:current_path]}"
  app_root = ::File.expand_path(::File.dirname(__FILE__)) + "/../"
  host = "#{deploy_config[:database][:host]}"
  database = "#{deploy_config[:database][:database]}"
  user = "#{deploy_config[:database][:username]}"
  pass = "#{deploy_config[:database][:password]}"

  bash "install_drupal" do
    user "root"
    cwd "#{app_root}"
    code <<-EOH
      echo "In #{app_root}" > dump.txt
      if [ ! -f #{app_root}/sites/default/settings.php ]; then
        echo "#{host} #{database} #{user} #{pass}" >> dump.txt
        mysql -h #{host} -u #{user} -p#{pass} -e "CREATE DATABASE IF NOT EXISTS #{database}"
        echo "Created database ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        cp #{app_root}/sites/default/default.settings.php #{app_root}/sites/default/settings.php
        echo "Copy settings.php ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        chmod a+w #{app_root}/sites/default/settings.php
        echo "Chmod settings.php ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        if [ ! -d #{app_root}/sites/default/files ]; then
            mkdir #{app_root}/sites/default/files
            echo "Creade dir files ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        fi
        chmod a+w #{app_root}/sites/default/files
        echo "Chmod dir files ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        /usr/bin/php #{app_root}/install.php
        echo "Execute install.php ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
        chmod a-w #{app_root}/sites/default/settings.php
        echo "Chmod settings.php ... " $(if [ $? == 0 ];then echo "OK";else echo "NOK";fi)"
      fi
    EOH
  end
end
