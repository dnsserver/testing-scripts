(function (jQuery) {
  "use strict";
  var image_extensions = ["png", "gif", "jpeg", "jpg"];

  function loadScript(url, callback) {
    var head = document.getElementsByTagName('head')[0],
      script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
    script.id = "dropboxjs";
    // Application Key
    jQuery(script).attr('data-app-key', "kkrr4ryxder49or");
    script.onreadystatechange = callback;
    script.onload = callback;

    head.appendChild(script);
  }

  CKEDITOR.plugins.add('dropbox', {
    init: function (editor) {
      editor.addCommand('dropbox_command', {
        exec: function (editor) {
          loadScript("https://www.dropbox.com/static/api/2/dropins.js", function () {
            var options = {
              success: function (files) {
                var n = files[0].name.split("."),
                  selection = editor.getSelection(),
                  data = "",
                  node = null;
                if (n.length > 1 && image_extensions.indexOf(n[1].toLowerCase()) >= 0) {
                  editor.insertHtml("<img src='" + files[0].link + "'/>");
                } else {
                  if (selection) {
                    if (selection.getType() === CKEDITOR.SELECTION_TEXT) {
                      data = selection.getSelectedText();
                    } else {
                      node = selection.getSelectedElement();
                      if (node) {
                        data = node.$.parentNode.innerHTML;
                      }
                    }
                  }
                  if(data===""){
                    data = files[0].link;
                  }
                  editor.insertHtml("<a href='" + files[0].link + "'>" + data + "</a>");
                }
              },
              cancel: function () {},
              linkType: "direct", // or "preview"
              multiselect: false // or true
              //extensions: ['.pdf', '.doc', '.docx','.png']
            };
            Dropbox.choose(options);
          });

        }
      });

      editor.ui.addButton('dropbox_button', {
        label: 'Add a file link from Dropbox', //this is the tooltip text for the button
        command: 'dropbox_command',
        icon: this.path + 'icons/abbr.png',
        toolbar: 'insert'
      });
    }
  });
})(jQuery);
